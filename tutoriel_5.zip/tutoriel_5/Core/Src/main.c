/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dfsdm.h"
#include "i2c.h"
#include "quadspi.h"
#include "spi.h"
#include "usart.h"
#include "usb_otg.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32l475e_iot01.h"
#include "capteurs.h"
#include "traitement_donnees.h"
#include "max30102_for_stm32_hal.h"


#include <wifi.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>


int32_t write_data_TS(int32_t* socket, uint16_t* datalen, int nb_parameters, ...);

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */


#define SSID "Javakjian"
#define PASSWORD "abcdefgh"
uint8_t RemoteIP[] = {10,34,124,150};
uint16_t RemotePORT = 8002;
uint8_t RemoteIP2[4] ;
uint16_t RemotePORT2 = 80;
#define thingspeak_APIkey_write "7RMGSWUJZXC89SFR"

#define thingspeak_APIkey_read "PS1YINWLA770M1BS"


#define WIFI_WRITE_TIMEOUT 10000
#define WIFI_READ_TIMEOUT 10000
#define CONNECTION_TRIAL_MAX 10


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
extern SPI_HandleTypeDef hspi;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/*Initialize WIFI module */
int wifi_connect(){
	int wifi_ok=0 ;
	uint8_t MAC_Addr[6] = {0};
	uint8_t IP_Addr[4] = {0};
	// Assure que NSS est haut



	if(WIFI_Init() == WIFI_STATUS_OK) {

		printf("> WIFI Module Initialized.\n\r");
		if(WIFI_GetMAC_Address(MAC_Addr, sizeof(MAC_Addr)) == WIFI_STATUS_OK) {
			printf("> es-wifi module MAC Address : %X:%X:%X:%X:%X:%X\n\r",MAC_Addr[0],MAC_Addr[1],MAC_Addr[2],MAC_Addr[3],MAC_Addr[4],MAC_Addr[5]);
		} else {
			printf("> ERROR : CANNOT get MAC address\n\r");
		}
		if( WIFI_Connect(SSID, PASSWORD, WIFI_ECN_WPA2_PSK) == WIFI_STATUS_OK) {
			printf("> es-wifi module connected \n\r");
			if(WIFI_GetIP_Address(IP_Addr, sizeof(IP_Addr)) == WIFI_STATUS_OK){
				printf("> es-wifi module got IP Address : %d.%d.%d.%d\n\r",IP_Addr[0],IP_Addr[1],IP_Addr[2],IP_Addr[3]);
				wifi_ok=-1 ;
			}
			else{
				printf("> ERROR : es-wifi module CANNOT get IP address\n\r");
			}
		}
		else{
			printf("> ERROR : es-wifi module NOT connected\n\r");
		}
	}
	else{
		printf("31 . . . \n") ;

		printf( "> ERROR : WIFI Module cannot be initialized.\n\r");
	}
	return(wifi_ok);
}

int Server_Connect(int Socket, uint8_t RemoteIP[], uint16_t RemotePORT){
	int16_t Trials = CONNECTION_TRIAL_MAX;
	printf( "> Trying to connect to Server: %d.%d.%d.%d:%d ...\n\r",
	RemoteIP[0], RemoteIP[1], RemoteIP[2], RemoteIP[3],
	RemotePORT);
	while (Trials--){
		if( WIFI_OpenClientConnection(Socket, WIFI_TCP_PROTOCOL, "TCP_CLIENT", RemoteIP, RemotePORT, 0) == WIFI_STATUS_OK){
			printf("> TCP Connection opened successfully.\n\r");
			break;
		}
	}
	if(Socket == -1){
		printf( "> ERROR : Cannot open Connection\n\r");
	}
	return(Socket);
}

bool resolve_hostname(char *hostname, uint8_t *RemoteIP ){
/* get the host address */
	printf("\nResolve hostname %s\r\n", hostname);
	WIFI_Status_t result = WIFI_GetHostAddress(hostname, RemoteIP, 4);
	if (result != 0) {
		printf("Error! GetHostAddress(%s) returned: %d\r\n", hostname,result);
		return false;
	}
	printf("%s address is %d.%d.%d.%d\r\n", hostname, RemoteIP[0],
	RemoteIP[1], RemoteIP[2], RemoteIP[3]);
	return true;
}

//GPS
char gps_buffer[128];
uint8_t gps_index = 0;
uint8_t c;

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */



	int32_t Socket2 = -1;

	float vf ;
	int v1,v2,v3,v4 ;
	char sbuffer[256];
	char message[100];


	int32_t Socket = -1;
	uint16_t Datalen;
	int32_t ret;
	char TxData [64] ; // reserve la zone de dialogue
	char RxData [500];
	float sensor_value ;




  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DFSDM1_Init();
  MX_QUADSPI_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();
  MX_USB_OTG_FS_PCD_Init();
  MX_SPI3_Init();
  MX_I2C1_Init();
  MX_UART4_Init();
  /* USER CODE BEGIN 2 */
  printf("****** Sensor initialization ******\n\n\r");
  BSP_TSENSOR_Init();
  BSP_HSENSOR_Init();
  BSP_PSENSOR_Init();
  BSP_MAGNETO_Init();
  BSP_GYRO_Init();
  BSP_ACCELERO_Init();

  init_sensors() ;

  /*Initialize WIFI module */

  /*if (wifi_connect()==-1)  {

		resolve_hostname("api.thingspeak.com",RemoteIP2);
		Socket2 = Server_Connect(1, RemoteIP2, RemotePORT2) ;
  	    //Socket =  Server_Connect(0, RemoteIP, RemotePORT) ;

  }*/
  // Je me suis permis de commenter mais à décommenter

  // --- Initialisation du capteur MAX30102 ---
  max30102_t max30102;
  char buffer[32];
  max30102_init(&max30102, &hi2c1);  // ⚠️ I2C1 utilisé (PA9, PA10)
  HAL_Delay(100);

  max30102_reset(&max30102);
  HAL_Delay(100);

  // --- Réglages optimisés pour meilleure amplitude PPG ---
  max30102_set_mode(&max30102, max30102_spo2);
  max30102_set_led_pulse_width(&max30102, max30102_pw_18_bit);
  max30102_set_adc_resolution(&max30102, max30102_adc_16384);
  max30102_set_sampling_rate(&max30102, max30102_sr_100);   // ↓ Taux plus faible, meilleur rapport signal/bruit
  max30102_set_fifo_config(&max30102, max30102_smp_ave_8, 1, 0);  // Moyenne sur 8 échantillons
  max30102_set_led_current_1(&max30102, 40.0f);   // IR LED (mA)
  max30102_set_led_current_2(&max30102, 20.0f);   // RED LED (mA)


  printf("\r\nMAX30102 prêt sur I2C1, lecture FIFO en cours...\r\n");



  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1){
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	 /*setAccelXYZ();
	  printf("ACCEL X: %.2f g, ACCEL Y: %.2f g, ACCEL Z: %.2f g \r\n\n", accel_raw_to_g(get_accel(0)), accel_raw_to_g(get_accel(1)), accel_raw_to_g(get_accel(2)));

	  printf("Magnitude : %.3f \r\n", vector_magnitude_g(get_accel(0), get_accel(1), get_accel(2)));
	  printf("Tilt ratio : %.3f \r\n\n", tilt_ratio(get_accel(0), get_accel(1), get_accel(2)));
	  printf("--------------------------------------------------------------------------------\n");

	  HAL_Delay(200) ;*/

	  /*if(Socket2 != -1){

		  setGyroXYZ();
		  setAccelXYZ();

		  //printf("GYRO X: %d, GYRO Y: %d, GYRO Z: %d \r\n", get_gyro_int(0), get_gyro_int(1), get_gyro_int(2));
		  printf("ACCEL X: %d, ACCEL Y: %d, ACCEL Z: %d \r\n", get_accel(0), get_accel(1), get_accel(2));

		  //setFreq(); fréquence cardiaque  à faire
		  //setGPSCoordinate() ; GPS coordonnées à faire

		  HAL_Delay(100) ;
		  ret = write_data_TS(&Socket2, &Datalen, 6, get_gyro_int(0),  get_gyro_int(1),  get_gyro_int(2), get_accel(0), get_accel(1), get_accel(2)) ;

		  if (ret != WIFI_STATUS_OK){
			  printf("> ERROR : Failed to Send Data, connection closed\n\r");
			  printf("> TRYING TO RECONNECT\n\r");

			  if (wifi_connect()==-1)  {

			  		resolve_hostname("api.thingspeak.com",RemoteIP2);
			  		Socket2 = Server_Connect(1, RemoteIP2, RemotePORT2) ;
			  }


		  }
		  else {
			  printf("request sent to thingspeak.com... status %d\r\n",(int)ret);//
			  HAL_Delay (5000);
		  }
	  }*/


//	  printf("%lu\n", max30102_get_ir_sample(&max30102));
//	  HAL_Delay(10); //Plus grand taux de rafraichissement donc commenter gyro pour la démo

	  //HAL_UART_Transmit(&huart1, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);


	    // Attend un caractère avec un timeout plus long (100ms)
	    if (HAL_UART_Receive(&huart4, &c, 1, 100) == HAL_OK) {
	        // Affiche chaque caractère pour debug
	        printf("%c", (isprint(c) ? c : '\n'));

	        // Stocke dans le buffer
	        gps_buffer[gps_index++] = c;

	        // Si fin de ligne (\n), affiche la trame complète
	        if (c == '\n') {
	            gps_buffer[gps_index] = '\0';
	            printf("\nTrame GPS complète: %s", gps_buffer);
	            gps_index = 0;  // Réinitialise pour la prochaine trame
	        }

	        // Évite le débordement
	        if (gps_index >= sizeof(gps_buffer)-1) {
	            gps_index = 0;
	            printf("\nBuffer plein, réinitialisation.\n");
	        }
	    }

  }


  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/* USER CODE BEGIN 4 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
 switch (GPIO_Pin)
 {
 case (GPIO_PIN_1):
 {
 SPI_WIFI_ISR();
 break;
 }
 default:
 {
 break;
 }
 }
}
int __io_putchar(int ch)
{
 HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xFFFF);
 return ch;
}



int32_t write_data_TS(int32_t* socket, uint16_t* datalen, int nb_parameters, ...){
    char sbuffer[512];
    char fields[256] = "{";
    va_list args;
    va_start(args, nb_parameters);

    for (int i = 1; i <= nb_parameters-1; i++) {
        char tmp[32];
        int val = va_arg(args, int);
        sprintf(tmp, "\"field%d\": %d, ", i, val);
        strcat(fields, tmp);
    }
    char tmp[32];
    int val = va_arg(args, int);
    sprintf(tmp, "\"field%d\": %d}", nb_parameters, val);
    strcat(fields, tmp);

    va_end(args);

    snprintf(sbuffer, sizeof(sbuffer), "GET /update?api_key=%s HTTP/1.1\r\nHost:api.thingspeak.com\r\nContent-Type: application/json\r\nContent-Length:%d\r\n\r\n%s", thingspeak_APIkey_write, (int)strlen(fields),fields);
    printf("HTTP command %s\r\n", sbuffer);


    return WIFI_SendData(*socket, (uint8_t *)sbuffer, strlen(sbuffer), datalen, WIFI_WRITE_TIMEOUT);
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
